# SEAHORS application
#
# This R shiny application dedicated to the intra-site spatial analysis of piece-plotted archaeological remains,making the two and three-dimensional spatial exploration of archaeological data as user-friendly as possible.
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

SEAHORS_application <- function() {
  appDir<-system.file("SEAHORS_application", package = "SEAHORS1.5")
  shiny::runApp(appDir, host='0.0.0.0', port=3838)
}
